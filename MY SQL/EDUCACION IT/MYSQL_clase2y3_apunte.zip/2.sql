/*Funciones agregadas*/
/*Funcion AVG() (promedio)*/

select avg(PRECIO) from PRODUCTOS;
select avg(PRECIO) from PRODUCTOS where MARCA = 'LEVIS';
/*Primero filtra por registros en el ultimo caso. En el primero es operacion general*/
select avg(IFNULL(PRECIO,0)) from PRODUCTOS;
/*En este caso estoy filtrando los valores cero y afino la operacion*/

------------------------------------------------------------------------
/*Funcion SUM() (suma)*/

select sum(CANTIDAD) from FACTURAS;
select sum(CANTIDAD) from FACTURAS where LETRA = 'A';

/*Funcion MAX() -- MIN()*/

select max(PRECIO), min(PRECIO) from PRODUCTOS;
select max(PRECIO), min(PRECIO), avg(PRECIO) from PRODUCTOS;
/*La segunda es una operacion combinada*/

------------------------------------------------------------------------
/*Funcion COUNT() (Me cuenta registros)*/

select count(*) from CLIENTES;
select count(TELEFONO) from CLIENTES;
/*Entre la primera linea y la segunda la diferencia es que en la primera me cuenta todos los registros
y en el segundo cuenta todos los valores validos que no sean NULL*/


------------------------------------------------------------------------

/*Funcion GROUP BY (agrupaciones)*/

/*PROMEDIO DE PRECIO DE MARCA LEVIS*/

select avg(PRECIO) from PRODUCTOS where marca = 'LEVIS';
select avg(PRECIO) from PRODUCTOS where marca = 'WRANGLER';

/*Resumimos con GROUP BY*/

select MARCA, TALLE, count(*), avg(PRECIO) from PRODUCTOS
group by MARCA, TALLE;

/*El codigo no se cierra en la linea 42 por que si se cerra no devuelve el GROUP BY como corresponde*/
/*Fijarse que datos conviene agrupar para traer correctamente los datos*/

------------------------------------------------------------------------------
/*Mostrar la cantidad total vendida por letra de factura*/

select LETRA, sum(CANTIDAD) from FACTURAS
group by LETRA;

-----------------------------------------------------------------------------
/*Mostrar cuantos clientes hombres y mujeres existen*/

select SEXO, count(*) from CLIENTES
group by SEXO;

-----------------------------------------------------------------------------
/*Cuantos productos existen por marca que sean talle L*/
Select MARCA, count(*) from PRODUCTOS where TALLE = 'L'
group by MARCA
having count(*) >=2; 

/*HAVING hace un segundo filtro de datos dependiendo el filtro asignado en la funcion*/

/*alt 62, alt 60 mayor y mejor*/

---------------------------------------------------------------------------
/*Mostrar los productos que tengan precio mayor al promedio*/
select avg(PRECIO) from PRODUCTOS;
/*Promedio*/
select * from PRODUCTOS where PRECIO > (select avg(PRECIO) from PRODUCTOS);
/*Incorporo el select del promedio dentro de la instruccion*/

/*Mostrar cuales productos tienen el mayor precio*/
select max(PRECIO) from PRODUCTOS;
select * from PRODUCTOS where PRECIO = (select max(PRECIO) from PRODUCTOS);

/*Mostrar las facturas de productos marca levis*/
select ID_PRODUCTO from PRODUCTOS where MARCA = 'LEVIS';
/*Nos indica cantidad de valores de ID*/
select * from FACTURAS where ID_PRODUCTO in (select ID_PRODUCTO from PRODUCTOS where MARCA = 'LEVIS');
/*Nos arroja datos dentro de la cantidad de valores de ID que es el dato relacionado en la consulta*/

-----------------------------------------------------------------
/*Sub consultas en el select*/
select LETRA, NUMERO, FECHA, CANTIDAD, ID_CLIENTE from FACTURAS;
/*Me trae datos solo con ID, ahora, yo quiero saber tambien el nombre del cliente entonces hacemos una sub consulta*/
select LETRA, NUMERO, FECHA, CANTIDAD, (select NOMBRE from CLIENTES where CLIENTES.ID_CLIENTE = FACTURAS.ID_CLIENTE) as NOMBRE_CLIENTE from FACTURAS;
/*as + nombre de alias me evita mostrar toda la formula y asignar el nombre que yo quiera a la columna*/
/*Colocar ID_CLIENTE no es excluyente para ejecutar la consulta de forma correcta en este paso*/
/*Forma 1*/
select LETRA, NUMERO, FECHA, CANTIDAD, 
(select NOMBRE from CLIENTES where CLIENTES.ID_CLIENTE = F.ID_CLIENTE) as NOMBRE_CLIENTE,
(select NOMBRE from PRODUCTOS as p where P.ID_PRODUCTO = F.ID_PRODUCTO) as NOMBRE_PRODUCTO  
from FACTURAS as F;
/*Tabular bien la consulta para evitar chorizos como la linea 91 Correjir*/
/*Forma 2*/

------------------------------------------------------------------------------------------------------
/*Sub consulta en FROM*/

select * from
	(select MARCA, count(*) as CANTIDAD from PRODUCTOS
	group by MARCA) 
    as TABLA1
    where cantidad=5;
    
/*Todos los campos tienen que tener un nombre en primera instancia y no un valor*/

------------------------------------------------------------------------------------------------------
/*Sentencia JOIN*/
/*Son consultas relacionadas, cuando hago una consulta en mas de una tabla al mismo tiempo (sobre dos tablas por ejemplo)*/

select * from FACTURAS as F, PRODUCTOS as P
where F.ID_PRODUCTO = P.ID_PRODUCTO;

/*Filtre los ID productos RELACIONADOS*/
/*Usamos JOIN y ON (trabajan conjuntamente) para escribir la consulta correctamente:*/
/*ANSI SQL estandariza programacion*/

select * from FACTURAS as F join PRODUCTOS as P
on F.ID_PRODUCTO = p.ID_PRODUCTO;

select * from FACTURAS as F join PRODUCTOS as P
on F.ID_PRODUCTO = p.ID_PRODUCTO
where LETRA = 'A' and MARCA = 'LEVIS';
/*Filtro por marca*/

select * from FACTURAS as F join PRODUCTOS as P
on F.ID_PRODUCTO = P.ID_PRODUCTO
join CLIENTES as C
on F.ID_CLIENTE = C.ID_CLIENTE;

/*Aplicando ahora otros conceptos aprendidos consultamos asi:*/

select * from FACTURAS as F join PRODUCTOS as P
on F.ID_PRODUCTO = P.ID_PRODUCTO
join CLIENTES as C
on F.ID_CLIENTE = C.ID_CLIENTE
where LETRA = 'A' and MARCA = 'LEVIS' and MAIL like '%GMAIL%';

/*Hago un filtrado mucho mas certero*/
------------------------------------------------------------
/* ejercicios*/
/*Mostrar facturas por letra, numero, cantidad, precio, monto total*/

select LETRA, NUMERO, CANTIDAD, PRECIO, (CANTIDAD*PRECIO) as MONTO_TOTAL from FACTURAS as F join PRODUCTOS as P
on F.ID_PRODUCTO = P.ID_PRODUCTO
where marca = 'LEVIS';

/*Agregando round() , cantidad de decimales, para agregarle decimales al valor, se aplica en cada campo por separado en caso
de utilizaro*/

/*MTA certificacion fundamentos de base de datos*/
/*
www.microsoft.com/learning
www.microsoftvirtualacademy.com
www.borntolearn.mslearn.net
www.learnvisualstudio.net
www.channel9.msdn.com
msdn.microsoft.com
*/




/*De esta forma se forma un conjunto carteciano entre dos productos, se duplican los datos de la consulta
por verificarse cada dato con cada variable entonces utilizamos JOIN*/





 
