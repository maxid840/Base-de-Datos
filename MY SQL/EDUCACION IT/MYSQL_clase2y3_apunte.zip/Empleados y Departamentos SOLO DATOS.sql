use comercio;


TRUNCATE TABLE EMPLEADOS;
TRUNCATE TABLE DEPARTAMENTOS;



insert into Departamentos Values
('ADM', 'Administracion', '1234'),
('INF', 'Informatica', '2323'),
('OPE', 'Operaciones', null),
('RRH', 'Recursos Humanos', null);

select * from Departamentos;

insert into Empleados values
('ADM', 101, 'Alfredo', 'Hernandez', 12345678, '20-12345678-8'),
('INF', 101, 'Luisa', 'Gimenez', 98765432, '21-98765432-5'),
('RRH', 101, 'Josefina', 'Añez', 11223344, '22-11223344-6'),
('INF', 102, 'Charles', 'Xavier', 22446688,null),
('OPE', 101, 'Alberto', 'Gutierrez', 11335577, null),
('ADM', 102, 'Juana', 'Martinez', 88664422, '22-88664422-4'),
('INF', 103, 'Manuel', 'Gil', 99775533, null),
('RRH', 102, 'Margarita', 'Fernandez', 77553311, '20-77553311-7'),
('OPE', 102, 'Angel', 'Gil', 99887766, null),
('ADM', 103, 'Juan', 'Domiguez', 44332211, '20-44332211-9');

select * from Empleados;
