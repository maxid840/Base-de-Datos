/*Sentencia DML*/
/*Sentencia UPDATE*/
/*Cambia el nombre al cliente 10 por ejemplo*/

/*UPDATE Simple

/*1 SELECT usando el WHERE que pienso usar en el UPDATE*/

select * from CLIENTES where ID_CLIENTE = 10;

/*2 ejecutar el UPDATE en una TRANSACCION*/

begin;
		update CLIENTES set NOMBRE = 'PEPE'where ID_CLIENTE = 10;
        select * from CLIENTES where ID_CLIENTE = 10;
rollback; /*COMMIT*/

/*Ejecutando las lineas 13, 14, 15 y 16 juntas nos muestra una vista previa de como quedaria*/
/*Ejecutando las dos lineas intermedias (11 y 12) se realiza el cambio permanentemente)*/
/*Ejecutar en ambos casos con rayito por ser mas de una linea de codigo*/

select * from CLIENTES where ID_CLIENTE = 10;

/*Ejecutamos el nombre como quedo guardado de forma definitiva.*/
/*En SQL Server es BEGIN TRAN .... ROLLBACK TRAN*/

/*UPDATE Multiple*/

/*Ahora vamos a aumentar en un 20% los PRODUCTOS marca LEVIS*/

select * from PRODUCTOS where MARCA = 'LEVIS';

begin;
		update PRODUCTOS set PRECIO = PRECIO * 1.2 where MARCA = 'LEVIS';
        select * from PRODUCTOS where MARCA = 'LEVIS';
rollback;

select * from PRODUCTOS where MARCA = 'LEVIS';
-----------------------------------------------------------------
/*FUNCION DELETE*/

/*Vamos a borrar la factura C-101*/

Select * from FACTURAS where LETRA = 'C' and NUMERO = 101;

begin;
		delete from FACTURAS where LETRA = 'C' and NUMERO = 101;
rollback;

Select * from FACTURAS where LETRA = 'C' and NUMERO = 101;
-----------------------------------------------------------------

