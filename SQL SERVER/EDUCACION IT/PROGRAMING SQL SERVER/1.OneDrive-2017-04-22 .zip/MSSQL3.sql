USE AdventureWorks2012
-------------------------------------------------------------------------------------------------
--										RELACIONES ENTRE VARIAS ENTIDADES
-------------------------------------------------------------------------------------------------

-- INNER JOIN 
SELECT 
		a.[BusinessEntityID]
FROM 
		[Person].[Person] a INNER JOIN [Person].[PersonPhone] b 
		ON a.[BusinessEntityID]=b.[BusinessEntityID];

-- LEFT JOIN
SELECT 
		a.[BusinessEntityID], 
		b.[BirthDate]
FROM 
		[Person].[Person] a LEFT OUTER JOIN [HumanResources].[Employee] b
		ON a.[BusinessEntityID]=b.[BusinessEntityID];

-- RIGHT JOIN
SELECT 
		s.[SalesOrderID], 
		c.[CustomerID]
FROM 
		[Sales].[SalesOrderHeader] AS s RIGHT OUTER JOIN [Sales].[Customer] AS c 
		ON s.[CustomerID] = c.[CustomerID]

-- FULL JOIN
SELECT 
		c.[CurrencyRateID], 
		s.[SalesOrderID]
FROM 
		[Sales].[SalesOrderHeader] AS s FULL OUTER JOIN [Sales].[CurrencyRate] AS c 
		ON c.[CurrencyRateID] = s.[CurrencyRateID]
ORDER BY 
		c.[CurrencyRateID], s.[SalesOrderID]

-------------------------------------------------------------------------------------------------------------
--										CLAUSULA UNION [ALL]
-------------------------------------------------------------------------------------------------------------
SELECT 
		[ProductModelID], 
		[Name]  
FROM 
		[Production].[ProductModel]  
WHERE 
		[ProductModelID] NOT IN (3, 4)  
UNION 
SELECT 
		[ProductModelID], 
		[Name]  
FROM 
		[Production].[ProductModel] 
ORDER BY 
		[ProductModelID] 


SELECT 
		[ProductModelID], 
		[Name]  
FROM 
		[Production].[ProductModel]  
WHERE 
		[ProductModelID] NOT IN (3, 4)	  
UNION  ALL
SELECT 
		[ProductModelID], [Name]  
FROM 
		[Production].[ProductModel] 
ORDER BY 
		[ProductModelID]  













