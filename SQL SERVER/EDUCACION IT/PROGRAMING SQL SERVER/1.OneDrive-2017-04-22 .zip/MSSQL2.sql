USE AdventureWorks2012;

-------------------------------------------------
-- CLAUSULA [NOT] IN
------------------------------------------------

SELECT 
		[Name]
FROM 
		[Person].[Contacttype]
WHERE	
		[Name] IN ('Owner','Sales Associate','Sales Manager');

SELECT 
		[BusinessEntityID], 
		[PhoneNumber], 
		[PhoneNumbertypeID], 
		[ModifiedDate]
FROM 
		[Person].[PersonPhone]
WHERE	
		[PhoneNumbertypeID] NOT IN (2,3);

-----------------------------------------------------------------------------------------
--								CLAUSULA [NOT] LIKE [ESCAPE]
--Tipo de coincidencia		Modelo Planteado		Coincide				No coincide

--Varios caracteres			'a%a'				'aa', 'aBa','aBXBa'			'aBC'
--Varios caracteres			'ab%'				'abcdefg', 'abc'			'cab', 'aab'
--Un solo car�cter			'a_a'				'aaa', 'a3a', 'aBa'			'aBBBa'
--Un solo d�gito			'a[0-9]a'			'a0a', 'a1a', 'a2a'			'aaa', 'a10a'
--Rango de caracteres		'[a-z]'				'f', 'p', 'j'				'2', '&'
--Fuera de un rango			'[^a-z]'			'9', '&', '%'				'b', 'a'
--Distinto de un d�gito		'[!0-9]'			'A', 'a', '&', '~'			'0', '1', '9'
--Combinada					'a[^b-m]#'			'An9', 'az0', 'a99'			'abc', 'aj0'
--------------------------------------------------------------------------------------------

SELECT 
		[BusinessEntityID],
		[rowguid]		-- 329EACBE-C883-4F48-B8B6-17AA4627EFFF
FROM
		[Person].[Password]
WHERE	[rowguid] LIKE '%B[0-9]B6%'

SELECT 
		[BusinessEntityID],		-- 1
		[rowguid]				-- 329EACBE-C883-4F48-B8B6-17AA4627EFFF
FROM
		[Person].[Password]
WHERE	[rowguid] LIKE '%8[A-B]6%';

-- CLAUSULA ESCAPE
DECLARE @email VARCHAR(20);
SET		@email='juan_perez@gmail.com' 

SELECT 
		@email AS email
WHERE	@email LIKE '%!_p%' ESCAPE '!';


-----------------------------------------------------------------------------------------
--								FUNCIONES DE AGREGADO
-----------------------------------------------------------------------------------------
SELECT 
		COUNT([SalesOrderID])		AS Cantidad,		-- 121317
		AVG([Orderqty])				AS PromedioOrden,	-- 2
		MAX([ModifiedDate])			AS MaximaFecha,		-- 2008-07-31 00:00:00.000
		SUM([Unitprice])			AS TotalPrecio
FROM 
		[Sales].[SalesOrderDetail]

-- COMPORTAMIENTO EN CAMPOS NULL
SELECT	
		COUNT([BusinessEntityID])	AS CantidadID,
		COUNT(*)					AS Cantidad,
		COUNT(1)					AS Cantidad_1,
		COUNT([EndDate])			AS CantidadFechas	
FROM
		[HumanResources].[EmployeeDepartmentHistory];

-- SOLUCION AL COMPORTAMIENTO EN CAMPOS NULL
SELECT
		COUNT([BusinessEntityID])			AS CantidadID,
		COUNT(*)							AS Cantidad,
		COUNT(1)							AS Cantidad_1, 
		COUNT(ISNULL([EndDate],GETDATE()))	AS CantidadFechas
FROM
		[HumanResources].[EmployeeDepartmentHistory];

-- AGRUPAMIENTO POR UN CAMPO
SELECT	
		[ProductID], 
		AVG([Unitprice]) AS 'Average [price]'
FROM 
		[Sales].[SalesOrderDetail]
GROUP BY 
		[ProductID]
ORDER BY 
		[ProductID];

-- AGRUPAMIENTO POR UN CAMPO Y USO DE HAVING
SELECT 
		[ProductID], 
		AVG([Unitprice]) AS 'Average [price]'
FROM 
		[Sales].[SalesOrderDetail] 
GROUP BY 
		[ProductID]
HAVING 
		AVG([Unitprice])<5000
ORDER BY 
		[ProductID];









/************************************************************************************
*																					*
*								LABORATORIO CLASE 2									*
*										PUBS										*
*																					*
************************************************************************************/
USE pubs;
-------------------------------------------------------------------------------------
-- 1_ Mostrar los t�tulos de los libros que tengan cualquier combinaci�n de 'computer'
-------------------------------------------------------------------------------------
SELECT 
		[title]
FROM 
		[dbo].[titles]
WHERE 
		[title] LIKE '%computer%'

-------------------------------------------------------------------------------------
-- 2_ Mostrar los autores que su nombre empieza con la letra N.
-------------------------------------------------------------------------------------
SELECT 
		[au_fName]
FROM  
		[dbo].[authors]
WHERE 
		[au_fName] LIKE 'N%'

-------------------------------------------------------------------------------------
-- 3_ Mostrar los autores que la segunda letra de su nombre es una A.
-------------------------------------------------------------------------------------
SELECT 
		[au_fName]
FROM  
		[dbo].[authors]
WHERE 
		[au_fName] LIKE '_a%'

-------------------------------------------------------------------------------------
-- 4_ Mostrar todos los autores con el nombre compuesto por alg�n n�mero
-------------------------------------------------------------------------------------
SELECT 
		[au_fName]
FROM  
		[dbo].[authors]
WHERE 
		[au_fName] LIKE '%[0-9]%'

-------------------------------------------------------------------------------------
-- 5_ Mostrar los c�digos de libros cuyo t�tulo tenga C o c como primer car�cter, 
--    cualquier otro como segundo car�cter, ni D ni d ni F ni g como tercer car�cter, 
--    cualquier entre J y R o entre S y W como cuarto car�cter y el resto sin restricciones
-------------------------------------------------------------------------------------
SELECT 
		[title]
FROM 
		[dbo].[titles]
WHERE 
		[title] LIKE '[C-c]_[^D-G][j-r,s-w]%'

-------------------------------------------------------------------------------------
-- 6_ Mostrar todas las categor�as distintas que existen
-------------------------------------------------------------------------------------
SELECT	DISTINCT 
		[type] 
FROM	
		[dbo].[titles]
-------------------------------------------------------------------------------------
-- 7_ Mostrar todos los c�digos distintos de tiendas que hayan vendido libros.
-------------------------------------------------------------------------------------
SELECT DISTINCT
		[title_id] 
FROM 
		[dbo].[sales]

-------------------------------------------------------------------------------------
-- 8_ Mostrar todas las fechas de facturas (pedidos) con cantidad mayor a 10 libros 
--    ordenado por n�mero de factura.
-------------------------------------------------------------------------------------
SELECT 
		[ord_date]
FROM 
		[dbo].[sales]
WHERE 
		[qty]>10
ORDER BY 
		[stor_id]

-------------------------------------------------------------------------------------
-- 9_ Mostrar todas las fechas de facturas (pedidos) con cantidad mayor a 10 libros 
--    ordenado por cantidad vendida en forma descendente.
-------------------------------------------------------------------------------------
SELECT 
		[ord_date]
FROM 
		[dbo].[sales]
WHERE 
		[qty]>10
ORDER BY 
		[qty] DESC

-------------------------------------------------------------------------------------
-- 10_ Mostrar todos los libros existentes ordenados por categor�a en forma ascendente y 
--     precio en forma descendente
-------------------------------------------------------------------------------------
SELECT 
		[title]
FROM	
		[dbo].[titles]
ORDER BY 
		[type] ASC, [price] DESC

-------------------------------------------------------------------------------------
-- 11_ Mostrar la fecha m�s reciente de venta.
-------------------------------------------------------------------------------------
SELECT 
		MAX([ord_date]) AS 'UltimaFactura'
FROM 
		[dbo].[sales]

-------------------------------------------------------------------------------------
-- 12_ Mostrar el precio m�s barato de los libros.
-------------------------------------------------------------------------------------
select 
		MIN([price]) 
from 
		[dbo].[titles]
-------------------------------------------------------------------------------------
-- 13_ Mostrar la cantidad de libros de cada categor�a, junto con la categor�a.
-------------------------------------------------------------------------------------
SELECT 
		[type],
		COUNT(1),
		COUNT(*),
		COUNT([title_id])
FROM 
		[dbo].[titles]
GROUP BY 
		[type]
-------------------------------------------------------------------------------------
-- 14_ Mostrar la cantidad de libros vendidos por cada tienda.
-------------------------------------------------------------------------------------
SELECT 
		[stor_id],
		COUNT(1)  AS cantidad
FROM 
		[dbo].[sales]
GROUP BY 
		[stor_id]

-------------------------------------------------------------------------------------
-- 15_ Mostrar la cantidad de libros vendidos por cada tienda y cada libro.
-------------------------------------------------------------------------------------
SELECT 
		[stor_id],
		[title_id],
		COUNT(1)  AS cantidad
FROM 
		[dbo].[sales]
GROUP BY 
		[stor_id],[title_id]

-------------------------------------------------------------------------------------
-- 16_ Mostrar la cantidad de facturas distintas (�rdenes) por cada libro.
-------------------------------------------------------------------------------------
SELECT 
		[ord_num],
		[title_id],
		COUNT(1)  AS cantidad
FROM 
		[dbo].[sales]
GROUP BY 
		[title_id],[ord_num]
-------------------------------------------------------------------------------------
-- 17_ Mostrar la cantidad de categor�as disponibles.
-------------------------------------------------------------------------------------
SELECT 
		[type]
FROM 
		[dbo].[titles]
GROUP BY 
		[type]

-------------------------------------------------------------------------------------
-- 18_ Mostrar el precio promedio actual de los libros, el precio promedio de los  
--     precios incrementado en un 15% y el precio promedio de los precios distinto.
-------------------------------------------------------------------------------------
SELECT 
		AVG([price]),
		AVG([price]*1.15),
		(AVG([price]*1.15)+AVG([price]))/2
		
FROM 
		[titles]
-------------------------------------------------------------------------------------
-- 19_ Mostrar el precio m�s caro de todos los libros.
-------------------------------------------------------------------------------------
SELECT 
		MAX([price])	
FROM 
		[dbo].[titles]

-------------------------------------------------------------------------------------
-- 20_ Mostrar las categor�as de libros que tienen dos o m�s libros que cuestan menos 
--     de $15 pero de diferente precio.
-------------------------------------------------------------------------------------
SELECT	COUNT(1) AS Cantidad,
		[type]
FROM 
		[dbo].[titles]
WHERE 
		[price]<15
GROUP BY 
		[type]
HAVING 
		COUNT(1)>2

-------------------------------------------------------------------------------------
-- 21_ Mostrar la cantidad de facturas por libro que vendieron m�s de 20 libros
-------------------------------------------------------------------------------------
SELECT  COUNT([ord_num]) AS Cantidad,
		[title_id]
FROM 
		[dbo].[sales]
WHERE 
		[qty]=20
GROUP BY 
		[title_id]

-------------------------------------------------------------------------------------
-- 22_ Mostrar la cantidad de facturas por tienda que hayan vendido m�s de 20 libros
-------------------------------------------------------------------------------------
SELECT  [stor_id],
		COUNT([stor_id])
FROM 
		[dbo].[sales]
GROUP BY 
		[stor_id]
HAVING 
		SUM([qty])>20


-------------------------------------------------------------------------------------
-- 23_ Mostrar la cantidad promedio vendida por tienda que hayan vendido m�s de 20 libros
-------------------------------------------------------------------------------------
SELECT  [stor_id],
		AVG([qty]) AS promedio_vendido
FROM 
		[dbo].[sales]
GROUP BY 
		[stor_id]
HAVING  
		SUM([qty])>20

-------------------------------------------------------------------------------------
-- 24_ Mostrar todas las categor�as existentes junto con la cantidad de libros y el 
--     precio promedio por cada una de aquellos libros que cuestan m�s de $7 y el 
--     precio promedio es mayor a $15.
-------------------------------------------------------------------------------------
SELECT 
		[type],
		COUNT([title_id])	AS Cantidad,
		AVG([price])		AS precio_promedio
FROM 
		[dbo].[titles]
WHERE 
		[price]>7
GROUP BY 
		[type]

-------------------------------------------------------------------------------------
-- 25_ Mostrar los t�tulos de los libros de negocio que no tienen decidido el precio
-------------------------------------------------------------------------------------
SELECT 
		[title]
FROM 
		[dbo].[titles]
WHERE 
		[type]='business'
		AND [price] IS NULL
-------------------------------------------------------------------------------------
-- 26_ Mostrar los t�tulos y los precios sumados a una base de $10. Considerar los 
--     libros que no tienen definido el precio como 0 (cero).
-------------------------------------------------------------------------------------
SELECT 
		[title],
		ISNULL([price],0)+10	AS precios
FROM 
		[dbo].[titles]

-------------------------------------------------------------------------------------
-- 27_ Mostrar los t�tulos de los libros que no tienen definida la categor�a.
-------------------------------------------------------------------------------------
SELECT  
		[title]
FROM 
		[dbo].[titles]
WHERE 
		[type] IS NULL


/************************************************************************************
*																					*
*								LABORATORIO CLASE 2									*
*								  ADVENTUREWORKS									*
*																					*
************************************************************************************/
USE AdventureWorks2012;
-------------------------------------------------------------------------------------
-- 1_ Mostrar todos los productos cuyo precio de lista est� entre 200 y 300
-------------------------------------------------------------------------------------
SELECT
		[Listprice]
FROM  
		[Production].[Product] 
WHERE 
		[Listprice] BETWEEN 200 AND 300;     

-------------------------------------------------------------------------------------
-- 2_ Mostrar todos los empleados que nacieron entre 1970 y 1985
-------------------------------------------------------------------------------------
SELECT 
		[BirthDate]
FROM 
		[HumanResources].[Employee]
WHERE 
		[BirthDate] BETWEEN '1970-01-01' AND '1985-12-31';

-------------------------------------------------------------------------------------
-- 3_ Mostrar los c�digos de venta y producto,cantidad de venta y precio unitario 
-- de los art�culos 750, 753 y 770
-------------------------------------------------------------------------------------
SELECT	
		[SalesOrderID], 
		[Orderqty], 
		[ProductID], 
		[Unitprice]
FROM	
		[Sales].[SalesOrderDetail]
WHERE	
		[ProductID] IN (750, 753, 770);

-------------------------------------------------------------------------------------
-- 4_ Mostrar todos los productos cuyo color sea verde, blanco y azul
-------------------------------------------------------------------------------------
SELECT 
		[Color]
FROM	
		[Production].[Product]
WHERE
		[Color] IN ('green','white','blue');

-------------------------------------------------------------------------------------
-- 5_ Mostrar el la fecha, numero de version y subtotal de las ventas efectuadas en 
--    los a�os 2005 y 2006
-------------------------------------------------------------------------------------
SELECT  
		[OrderDate], 
		[AccountNumber],
		[SubTotal]
FROM
		[Sales].[SalesOrderHeader]
WHERE   
		[OrderDate] BETWEEN  '2005-01-01' AND '2006-12-31';

-------------------------------------------------------------------------------------
-- 6_ Mostrar el nombre, precio y color de los accesorios para asientos de las 
--    bicicletas cuyo precio sea  mayor a 100 pesos
-------------------------------------------------------------------------------------
SELECT  
		[Name],
		[Listprice],
		[Color]
FROM	
		[Production].[Product]
WHERE   
		[ListPrice]>100;
-------------------------------------------------------------------------------------
-- 7_ Mostrar trar las bicicletas de monta�a que  cuestan entre $1000 y $1200
-------------------------------------------------------------------------------------
SELECT  
		[ProductNumber],
		[Listprice]
FROM	
		[Production].[Product]
WHERE  
		[Listprice]  BETWEEN 1000 AND 1200;

-------------------------------------------------------------------------------------
-- 8_ Mostrar los nombre de los productos que tengan cualquier combinaci�n de 
--    mountain bike
-------------------------------------------------------------------------------------
SELECT  
		[Name],
		[Listprice]
FROM	
		[Production].[Product]
WHERE 
		[Name] LIKE '%mountain bike%';

-------------------------------------------------------------------------------------
-- 9_ Mostrar las personas que su nombre empiece con la letra �y�
-------------------------------------------------------------------------------------
SELECT	
		[FirstName]
FROM  
		[Person].[Person]
WHERE 
		[FirstName] LIKE 'y%';

-------------------------------------------------------------------------------------
-- 10_ Mostrar las personas que la segunda letra de su apellido es una s
-------------------------------------------------------------------------------------
SELECT	
		[LastName]
FROM  
		[Person].[Person]
WHERE 
		[LastName] LIKE '_a%';
-------------------------------------------------------------------------------------
-- 11_ Mostrar el nombre concatenado con el apellido de las personas cuyo apellido 
--     tengan terminaci�n espa�ola (ez)
-------------------------------------------------------------------------------------
SELECT	
		[LastName]
FROM  
		[Person].[Person]
WHERE 
		[LastName] LIKE '%ez';

-------------------------------------------------------------------------------------
-- 12_ Mostrar los nombres de los productos que su nombre termine en un n�mero
-------------------------------------------------------------------------------------
SELECT	
		[Name]
FROM  
		[Production].[Product]
WHERE 
		[Name] LIKE '%[0-9]';

-------------------------------------------------------------------------------------
-- 12_ Mostrar las person]as cuyo  nombre tenga una C o c como primer caracter, 
--     cualquier otro como segundo caracter, ni d ni d ni f ni g como tercer caracter, 
--     cualquiera entre j y r o entre s y w como cuarto caracter y el resto sin 
--     restricciones
-------------------------------------------------------------------------------------
SELECT 
		[FirstName]
FROM	
		[Person].[Person]
WHERE 
		[FirstName] LIKE '[C-c]_[^d-g][j-r,s-w]%';
-------------------------------------------------------------------------------------
-- 13_ Mostrar las personas ordenadas primero por su apellido y luego por su nombre
-------------------------------------------------------------------------------------
SELECT  
		[FirstName],
		[LastName]
FROM 
		[Person].[Person]
ORDER BY 
		[LastName], [FirstName];

-------------------------------------------------------------------------------------
-- 14_ Mostrar cinco productos m�s caros y su nombre ordenado en forma alfab�tica
-------------------------------------------------------------------------------------
SELECT TOP 5
		[Name],
		[Listprice]
FROM	
		[Production].[Product]
ORDER BY 
		[Listprice] DESC, [Name];
		
-------------------------------------------------------------------------------------
-- 15_ Mostrar la fecha m�s reciente de venta
-------------------------------------------------------------------------------------
SELECT		
		MAX([OrderDate]) AS UltimaFactura
FROM 
		[Sales].[SalesOrderHeader];

-------------------------------------------------------------------------------------
-- 16_ Mostrar el precio m�s barato de todas las bicicletas
-------------------------------------------------------------------------------------
SELECT  [Listprice], 
		[ProductNumber]
FROM 
		[Production].[Product];

-------------------------------------------------------------------------------------
-- 17_ Mostrar la fecha de nacimiento del empleado m�s joven
-------------------------------------------------------------------------------------
SELECT 
		MIN([BirthDate]) AS [Mas Joven]
FROM  
		[HumanResources].[Employee];
-------------------------------------------------------------------------------------
-- 18_ Mostrar los representantes de ventas (vendedores) que no tienen definido el 
--     n�mero de territorio
-------------------------------------------------------------------------------------
SELECT  
		[BusinessEntityID],
		[TerritoryID]
FROM	
		[Sales].[SalesPerson]
WHERE	
		[TerritoryID] IS NULL;

-------------------------------------------------------------------------------------
-- 19_ Mostrar el peso promedio de todos los art�culos. si el peso no estuviese 
--     definido, reemplazar por cero
-------------------------------------------------------------------------------------
SELECT  
		AVG([Weight])				AS [Promedio Mal Calculado], -- Hay valores NULL
		AVG(ISNULL([Weight],0))		AS [PromedioBienCalculado]
FROM 
		[Production].[Product];


-------------------------------------------------------------------------------------
-- 20_ Mostrar el c�digo de subcategor�a y el precio del producto m�s barato de cada 
--     una de ellas
-------------------------------------------------------------------------------------
SELECT  
		[ProductSubcategoryID],
		MIN([Listprice])	AS [Mas Barato]
FROM	
		[Production].[Product]
GROUP BY 
		[ProductSubcategoryID];

-------------------------------------------------------------------------------------
-- 20_ Mostrar los productos y la cantidad total vendida de cada uno de ellos
-------------------------------------------------------------------------------------
SELECT 
		[ProductID], 
		SUM([Orderqty]) AS [Total Vendido]
FROM		
		[Sales].[SalesOrderDetail]
GROUP BY 
		[ProductID];

-------------------------------------------------------------------------------------
-- 21_ Mostrar los productos y la cantidad total vendida de cada uno de ellos, 
--     ordenarlos por mayor cantidad de ventas
-------------------------------------------------------------------------------------
SELECT  
		[ProductID], 
		SUM([Orderqty]) AS  [Total Vendido]
FROM 
		[Sales].[SalesOrderDetail]
GROUP BY 
		[ProductID]
ORDER BY 
		SUM([Orderqty]);

-------------------------------------------------------------------------------------
-- 22_ Mostrar todas las facturas realizadas y el total facturado de cada una de ellas 
--     ordenado por n�mero de factura.
-------------------------------------------------------------------------------------
SELECT 
		[SalesOrderID],
		SUM([Unitprice]*[Orderqty]) AS [Total Facturado]
FROM	
		[Sales].[SalesOrderDetail]
GROUP BY 
		[SalesOrderID]

-------------------------------------------------------------------------------------
-- 23_ Mostrar todas las facturas realizadas y el total facturado de cada una de ellas 
--     ordenado por n�mero de factura  pero s�lo de aquellas �rdenes superen un total 
--     de $10.000
-------------------------------------------------------------------------------------
SELECT 
		[SalesOrderID],
		SUM([Unitprice]*[Orderqty]) AS [Total Facturado]
FROM		
		[Sales].[SalesOrderDetail]
GROUP BY 
		[SalesOrderID]
HAVING 
		SUM([Unitprice]*[Orderqty])>10000
ORDER BY 
		[SalesOrderID];

-------------------------------------------------------------------------------------
-- 24_ Mostrar la cantidad de facturas que vendieron m�s de 20 unidades
-------------------------------------------------------------------------------------
SELECT 
		[SalesOrderID], 
		SUM([Orderqty])  AS [Total Vendido]    
FROM	
		[Sales].[SalesOrderDetail]
GROUP BY 
		[SalesOrderID]
HAVING 
		SUM([Orderqty])>20;

-------------------------------------------------------------------------------------
-- 25_ Mostrar las subcategor�as de los productos que tienen dos o m�s productos que 
--     cuestan menos de $150
-------------------------------------------------------------------------------------
SELECT 
		[ProductSubcategoryID]
FROM	
		[Production].[Product]
WHERE 
		[Listprice]<150
GROUP BY 
		[ProductSubcategoryID]
HAVING 
		COUNT([ProductSubcategoryID])>2;

-------------------------------------------------------------------------------------
-- 26_ Mostrar todos los codigos de categorias existentes junto con la cantidad de 
--     productos y el precio de lista promedio por cada uno de aquellos productos que 
--     custan mas de $ 70 y el precio promedio es mayor a $ 300.
-------------------------------------------------------------------------------------
SELECT  
		[ProductSubcategoryID], 
		COUNT([ProductSubcategoryID])	AS [Cantidad],
		AVG([Listprice])				AS [Promedio]	
FROM 
		[Production].[Product]
WHERE 
		[Listprice]>70
GROUP BY 
		[ProductSubcategoryID]
HAVING 
		AVG([Listprice])>300;
