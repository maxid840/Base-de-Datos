USE AdventureWorks2012;

-------------------------------------------------------------
--						BATCH USO DE GO -- procedimiento por bloques
-------------------------------------------------------------
-- Creacion del procedimeiento
IF OBJECT_ID (N'dbo.batch', N'P') IS NOT NULL
		DROP PROCEDURE  dbo.batch;
go	  -- si no lo pongo antes del create me tira error, el create es la primera instruccion de un lote
CREATE PROCEDURE dbo.batch
AS BEGIN 
		RETURN 0;
END


IF OBJECT_ID (N'dbo.batch', N'P') IS NOT NULL
		DROP PROCEDURE  dbo.batch;
go


---------------------------------------------------------------
--						VARIABLES
---------------------------------------------------------------

-- DECLARACION 
DECLARE @nombre VARCHAR(20), @precio INT;
DECLARE @sexo	CHAR(1);

--INICIALIZACION UTILIZANDO SET
SET @sexo=4;
SET @precio= (SELECT MAX(ListPrice) FROM Production.Product);


--INICIALIZACION UTILIZANDO SELECT
SELECT @precio = MAX(ListPrice) FROM Production.Product; 

-- ACCESO AL VALOR DE LA VARIABLE UTILIZNDO SELECT
SELECT @precio;

-- ACCESO AL VALOR DE LA VARIABLE UTILIZNDO PRINT
PRINT '	El precio es: '+CAST(@precio AS VARCHAR);-- cast convirtio a varchar,vale el convert tambien

---------------------------------------------------------------
--						VARIABLES TIPO TABLA
---------------------------------------------------------------
--DECLARACION DE VARIABLE
DECLARE @VariableTabla TABLE 
(
		Campo1	INT  NOT NULL IDENTITY(1,1), 
		Campo2	CHAR(50),
		PRIMARY KEY (Campo1) -- Solo indices agrupados [CLUSTERED-UNICKE]

)

-- INICIALIZACION DE UNA VARIABLE DEL TIPO TABLA
INSERT INTO @VariableTabla VALUES('PESO'), ('DOLAR')


---------------------------------------------------------------
--		VARIABLES DEL SISTEMA SOLO LECTURA
---------------------------------------------------------------
SELECT @@SERVERNAME
SELECT @@SPID

---------------------------------------------------------------
--		ESTRUCTURA IF-ELSE
---------------------------------------------------------------
-- UTILIZANDO VARIABLES
DECLARE @valor int
SET @valor=55

IF @valor<10 
	PRINT 'EL PRECIO ES MUY BAJO' -- No requiere BEGIN-END ya que solo hay una instruccion
ELSE
	PRINT 'EL PRECIO ES MUY CARO' -- No requiere BEGIN-END ya que solo hay una instruccion

-- UTILIZANDO CONSULTAS
IF EXISTS (SELECT COUNT(1) FROM [Person].[Person])
BEGIN 
			PRINT 'HAY PERSONAL TRABAJANDO'
			PRINT 'NO HAY PROBLEMAS'
END
ELSE
BEGIN
			PRINT 'NO HAY PERSONAL TRABAJANDO'
			PRINT 'HAY PROBLEMAS'
END
	
IF  (SELECT COUNT(1) FROM [Person].[Person])=1
BEGIN 
			PRINT 'HAY PERSONAL TRABAJANDO'
			PRINT 'NO HAY PROBLEMAS'
END
ELSE
BEGIN
			PRINT 'NO HAY PERSONAL TRABAJANDO'
			PRINT 'HAY PROBLEMAS'
END
		
---------------------------------------------------------------
--		ESTRUCTURA WHILE-BREAK-CONTINUE-WAITFOR [DELAY|TIME]	
---------------------------------------------------------------	

DECLARE @indice INT;
SET  @indice=0 ;

WHILE (@indice<=10)	
BEGIN 
		PRINT @indice;
		
		IF @indice<5
			PRINT 'EL NUMERO EL MENOR QUE 5';

		IF @indice=7
		BEGIN 
			SET @indice=@indice+1;

			WAITFOR DELAY '00:00:20'

			CONTINUE;
		END
		
		-- dos formas de salir forzando el while
		IF @indice=8 GOTO mensaje; -- NO USAR

		IF @indice=9 BREAK;
		----------------------------------------

		SET @indice=@indice+1;
END

mensaje:
		PRINT 'SALI DEL WHILE POR EL GOTO'

---------------------------------------------------------------
--		INJECCCION SLQ -- guarda una consulta dentro de una variable, lo que esta entre ''
---------------------------------------------------------------
DECLARE @sql NVARCHAR(50);
SET @sql='SELECT TOP 1 * FROM [HumanResources].[Employee]';

EXECUTE ('SELECT TOP 1 * FROM [HumanResources].[Employee]');
EXECUTE (@sql);

EXECUTE sp_executesql @sql;  -- La variable debe ser de tipo Nvarchar

---------------------------------------------------------------
--		ESTRUCTURA CASE	
---------------------------------------------------------------		
SELECT	[Gender],
		CASE 
			WHEN [Gender]='M' THEN 'Masculino'
			WHEN [Gender]='F' THEN 'Femenino'
			--...
			--... Fin de condiciones
			ELSE 'No establecido' 	
		END
FROM 
		[HumanResources].[Employee]

-----------------------------------------------------------------
-- MANEJO DE ERRORES CON SQL {TRY - CATCH] 
-----------------------------------------------------------------
IF OBJECT_ID (N'dbo.errores', N'U') IS NOT NULL
		DROP TABLE  dbo.errores;

CREATE TABLE dbo.errores (id INT);

SELECT * FROM dbo.errores
GO
alter PROCEDURE insert_data @a int, @b int 
AS
BEGIN 
   SET XACT_ABORT, NOCOUNT ON
   BEGIN TRY
      BEGIN TRANSACTION
			INSERT errores(id) VALUES (@a/@b)
			/*IF @@ERROR<>0
					BEGIN 
						
						ROLLBACK TRANSACTION;
						
						RETURN; 
					END*/
      COMMIT TRANSACTION
   END TRY
   BEGIN CATCH
      IF @@trancount > 0 ROLLBACK TRANSACTION;
	  /*SELECT ERROR_NUMBER() AS errNumber
						, ERROR_SEVERITY() AS errSeverity 
						, ERROR_STATE() AS errState
						, ERROR_PROCEDURE() AS errProcedure
						, ERROR_LINE() AS errLine
						, ERROR_MESSAGE() AS errMessage*/
      --DECLARE @msg nvarchar(2048) = error_message()  
     -- RAISERROR (@msg, 16, 1)
	 
	 --todo lo anterior desde select error_number se resuelve con throw de abajo
	 THROW;
      
   END CATCH
END
GO

-- Inserto valores
EXEC insert_data 1, 0;

IF OBJECT_ID (N'dbo.errores', N'U') IS NOT NULL
		DROP TABLE  dbo.errores;


-----------------------------------------------------------------
--							TRIGGERS -- tipo de procedimiento almacenado que se ejecuta solo con insert, update, delete.
-----------------------------------------------------------------
IF OBJECT_ID (N'dbo.prueba', N'U') IS NOT NULL
		DROP TABLE  dbo.prueba;

CREATE TABLE prueba (codigo INT, nombre VARCHAR(50))


/* CREO EL TRIGGER */
IF OBJECT_ID (N'dbo.ti_prueba', N'TR') IS NOT NULL
		DROP TRIGGER  dbo.ti_prueba;
GO

CREATE TRIGGER ti_prueba
        ON prueba FOR INSERT
AS
BEGIN
        PRINT 'REGISTRO NUEVO'
END


/* INSERTO UN REGISTRO EN LA TABLA PRUEBA  Y  ESO DISPARARA EL TRIGGER */
INSERT INTO prueba
SELECT 1,'GABRIEL'

INSERT INTO prueba
SELECT 2,'CARLOS'

INSERT INTO prueba
SELECT 3,'JUAN'

SELECT * FROM prueba
GO

----------------------------------------------------------------------
-- Inserto un registro en la tabla prueba  y eso disparara el trigger
---------------------------------------------------------------------- 
ALTER TRIGGER ti_prueba
ON prueba FOR UPDATE
AS
BEGIN
        PRINT 'REGISTRO MODIFICADO'
END


UPDATE prueba
SET NOMBRE='OMAR'
WHERE CODIGO=1

SELECT * FROM prueba
GO

---------------------------------------------------------------------
-- Inserto un registro en la tabla prueba  y eso disparara el trigger 
---------------------------------------------------------------------
ALTER TRIGGER ti_prueba
ON prueba FOR DELETE
AS
BEGIN
        PRINT 'REGISTRO BORRADO'
END

DELETE FROM prueba
WHERE NOMBRE LIKE '%OMAR%'

SELECT * FROM prueba
GO

-- Inserto un registro en la tabla prueba  y eso disparara el trigger 
ALTER TRIGGER ti_prueba
ON prueba FOR INSERT,UPDATE,DELETE
AS
BEGIN
        PRINT 'SE REALIZO ALGUNA OPERACION EN EL REGISTRO'
END


DELETE FROM prueba
WHERE NOMBRE LIKE '%JUAN%'

SELECT * FROM prueba
GO

----------------------------------------------------------------------
--  Inserto un registro en la tabla prueba  y eso disparara el trigger
----------------------------------------------------------------------- 
ALTER TRIGGER ti_prueba
ON prueba FOR INSERT
AS
BEGIN

        SELECT HOST_NAME() USUARIO,SUSER_NAME(),GETDATE() FECHA, 'DATOS INGRESADOS',CODIGO,NOMBRE
        FROM INSERTED /* DELETED ES CUANDO ELIMINA */

END

INSERT INTO prueba
SELECT 4,'GABRIEL'

SELECT * FROM prueba
GO
---------------------------------------------------------------------------
-- Inserto un registro en la tabla prueba  y eso disparara el trigger 
---------------------------------------------------------------------------
ALTER TRIGGER ti_prueba
ON prueba FOR UPDATE
AS
BEGIN

        SELECT HOST_NAME() USUARIO, SUSER_NAME(), GETDATE() FECHA, 'DATOS INGRESADOS',CODIGO,NOMBRE
        FROM INSERTED /* DELETED ES CUANDO ELIMINA */
        UNION
        SELECT HOST_NAME() USUARIO,SUSER_NAME(),GETDATE() FECHA, 'DATOS INGRESADOS',CODIGO,NOMBRE
        FROM DELETED
END


UPDATE prueba
SET NOMBRE='OMAR'
WHERE CODIGO=2

SELECT * FROM prueba
GO



IF OBJECT_ID (N'dbo.ti_prueba', N'TR') IS NOT NULL
		DROP TRIGGER  dbo.ti_prueba;
GO