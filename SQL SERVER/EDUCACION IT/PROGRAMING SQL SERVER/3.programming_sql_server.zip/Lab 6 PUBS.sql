---------------------------------------------------------------------------------------------------------
--Manejo de Variables
---------------------------------------------------------------------------------------------------------

--1) Hacer un script SQL donde acumule en una variable el total de libros vendidos 
declare @cant_vendidad int

select @cant_vendida = SUM(qty) FROM sales


--2) Hacer un script SQL donde guarde en una variable con el nombre �@prom� el precio promedio de los libros y luego hacer un reporte de todos los libros cuyo precio sea superior al precio promedio ( utilizando la variable @prom)
declare @prom money

select @prom = AVG(price) FROM titles

select * from titles where price > @prom

--3) Utilizando la variable @prom, incrementar todos los libros un 10% excepto aquellos libros cuyo valor supera el precio promedio
declare @prom money

select @prom = AVG(price) FROM titles

update titles set price = price * 1.10 where price <= @prom

--4) Utilizando la variable @prom, incrementar todos los libros un 10% excepto aquellos libros cuyo valor supera dos veces el precio promedio
declare @prom money

select @prom = AVG(price) FROM titles

update titles set price = price * 1.10 where price <= @prom*2

--5) Crear un variable de tipo tabla con las categor�as de libros y la cantidad de libros por categor�a
declare @x table( tipo varchar(50), cant int )

insert into @x
select type, count(*) from titles group by type

select * from @x
    

---------------------------------------------------------------------------------------------------------
--TRANSACCIONES
---------------------------------------------------------------------------------------------------------


--1) Borrar todos los autores que no escribieron libros dentro de una transacci�n y luego deshacer la operaci�n.

Begin tran

delete a
from authors a
where not exists( select 1 from titleauthor t where t.au_id = a.au_id )

Rollback



--2) Incrementar todos los libros un 15% pero si el precio m�nimo supera el contenido de la variable @prom abortar toda la operaci�n.
Begin tran

declare @prom money

select @prom = AVG(price) FROM titles

update titles set price = price * 1.15 

if @prom < ( select MIN(price) from titles ) 
	Rollback tran
else
	commit tran



---------------------------------------------------------------------------------------------------------
--TRIGGERS
---------------------------------------------------------------------------------------------------------
--1) Hacer un trigger sobre la tabla titles donde actualize en una tabla log todos los cambios de precio, guardando el title_id, precio_viejo y precio_nuevo

create table log(
 	title_id	varchr(50), 
	precio_viejo 	money,
	precio_nuevo	money  )


CREATE TRIGGER titles
	ON trigger_log FOR UPDATE
AS
BEGIN
	IF ( exists( select 1 from inserted i, deleted d where i.title_id = d.title_id and i.price <> d.price )
		insert into log
		select i.title_id, d.price, i.price	

END

--2) Crear un trigger de insert sobre la tabla titles donde valide que el precio del libro no puede ser negativo
CREATE TRIGGER ti_titles
	ON titles FOR INSERT
AS
BEGIN
	IF exists( select 1 from inserted i where i.price < 0 ) 
	begin
		THROW 51000,'No se puede insertar un libro con precio negativo', 1
		rollback
	end


END


--3) Adaptar el tirgger del punto anterior para tambi�n los updates. Osea controlar que no puedan modificar el precio de un libro con un valor negativo.
CREATE TRIGGER tiu_titles
	ON titles FOR INSERT, UPDATE
AS
BEGIN
	IF  exists( select 1 from inserted i where i.price < 0 ) 
	begin
		THROW 51000,'No se puede insertar un libro con precio negativo', 1
		rollback
	end


END


---------------------------------------------------------------------------------------------------------
--Herramienta CASE
---------------------------------------------------------------------------------------------------------
--1 Mostrar todos los libros de la tabla titles ordenados con el siguiente criterio: Todos deben estar ordenado por categoria pero primero los libros que sean de alguna de las categor�as de tipos de cocina (osea que el campo type contenga la cadena de caracteres cook), despu�s el resto de las categor�as (que no sean de cocina) deben estar ordenadas alfab�ticamente, pero a su vez todos los libros que pertenecen a la misma categor�a deben estar ordenados por precio en forma descendente.
select 	* 
from 	titles
order by
	case when type like '%cook%' then 1 else 2 end,
	type,
	price desc

--2Mostrar nombre y precio de la tabla titles y tambi�n mostrar una categor�a de libros seg�n el precio de acuerdo al siguiente criterio:
--Si es valor es menor a 5 es libro es de categoria Barato
--Si es valor es mayor o igual a 5 y menor o igual a 7  es libro es de categor�a Intermedio
--Si es valor es mayor a 7  es libro es de categor�a Caro
--Si el precio es NULL la categor�a No definido
select 	title,
		price,
		case when price < 5 then 'Barato'
			 when price between 5 and 7 then 'Intermedio'
			 when price > 7 then 'Caro'
			 else 'No definido' end 
from	titles	