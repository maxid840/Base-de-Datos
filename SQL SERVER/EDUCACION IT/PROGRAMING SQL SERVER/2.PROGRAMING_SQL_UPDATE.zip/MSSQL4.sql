USE AdventureWorks2014

-------------------------------------------------------------------------------------------------------------
--										SUBCONSULTAS CON [NOT] IN
-------------------------------------------------------------------------------------------------------------
SELECT 
		[FirstName],
		[MiddleName],
		[LastName]
FROM 
		[Person].[Person]
WHERE	
		[BusinessEntityID] IN ( 
									SELECT 
											[BusinessEntityID]
									FROM 
											[Sales].[SalesPerson]			
							   );

SELECT 
		[FirstName],
		[MiddleName],
		[LastName]
FROM 
		[Person].[Person]
WHERE	
		[BusinessEntityID] NOT IN	( 
										SELECT  DISTINCT
												[BusinessEntityID]
										FROM 
												[Sales].[SalesPerson]	
									);
-------------------------------------------------------------------------------------------------------------
--										SUBCONSULTAS CON [NOT] EXISTS
-------------------------------------------------------------------------------------------------------------
SELECT 
		[FirstName],
		[MiddleName],
		[LastName]
FROM 
		[Person].[Person] p
WHERE	
		EXISTS  ( 
						SELECT 
								1
						FROM 
								[Sales].[SalesPerson] s
						WHERE	
								p.[BusinessEntityID]=s.[BusinessEntityID]
														
				);

SELECT 
		[FirstName],
		[MiddleName],
		[LastName]
FROM 
		[Person].[Person] p
WHERE	
		NOT EXISTS  ( 
						SELECT 
								[BusinessEntityID]
						FROM 
								[Sales].[SalesPerson] s
						WHERE	
								p.[BusinessEntityID]=s.[BusinessEntityID]
														
					);
-------------------------------------------------------------------------------------------------------------
--										SUBCONSULTAS CON [ANY|SOME - ALL]
-------------------------------------------------------------------------------------------------------------
CREATE TABLE _A (ID INT);
CREATE TABLE _B (ID INT);

INSERT INTO _A VALUES (1),(2),(3),(4),(5),(6),(7),(8),(9),(10);
INSERT INTO _B VALUES (1),(2),(3),(4),(5);

SELECT * FROM _A
SELECT * FROM _B

---------------------------------------------- ANY|SOME --------------------------------------
--(1),(2),(3),(4),(5),(6),(7),(8),(9),(10);
--(1),(2),(3),(4),(5);

------------------------------------------------------------------------------------------
--	= ANY ES EQUIVALENTE A IN
------------------------------------------------------------------------------------------

--  A (1),(2),(3),(4),(5),(6),(7),(8),(9),(10);
--  B (1),(2),(3),(4),(5);

SELECT ID
FROM _A
WHERE ID =ANY(SELECT ID FROM _B)

--  A (1),(2),(3),(4),(5),(6),(7),(8),(9),(10);
--  B (1),(2),(3),(4),(5);
SELECT ID
FROM _A
WHERE ID >=ANY(SELECT ID FROM _B)

--  A (1),(2),(3),(4),(5),(6),(7),(8),(9),(10);
--  B (1),(2),(3),(4),(5);
SELECT ID
FROM _A
WHERE ID >ANY(SELECT ID FROM _B)

--  A (1),(2),(3),(4),(5),(6),(7),(8),(9),(10);
--  B (1),(2),(3),(4),(5);
SELECT ID
FROM _A
WHERE ID >ANY(SELECT MAX(ID) FROM _B)

--  A (1),(2),(3),(4),(5),(6),(7),(8),(9),(10);
--  B (1),(2),(3),(4),(5);
SELECT ID
FROM _B
WHERE ID >ANY(SELECT MAX(ID) FROM _A)

---------------------------------------------- ALL --------------------------------------
--  A (1),(2),(3),(4),(5),(6),(7),(8),(9),(10);
--  B (1),(2),(3),(4),(5);
SELECT ID
FROM _A
WHERE ID =ALL(SELECT ID FROM _B)

--  A (1),(2),(3),(4),(5),(6),(7),(8),(9),(10);
--  B (1),(2),(3),(4),(5);
SELECT ID
FROM _A
WHERE ID >ALL(SELECT ID FROM _B)

--  A (1),(2),(3),(4),(5),(6),(7),(8),(9),(10);
--  B (1),(2),(3),(4),(5);
SELECT ID
FROM _A
WHERE ID <=ALL(SELECT ID FROM _B)

--  A (1),(2),(3),(4),(5),(6),(7),(8),(9),(10);
--  B (1),(2),(3),(4),(5);
SELECT ID
FROM _A
WHERE ID >ALL(SELECT MAX(ID) FROM _B)

------------------------------------------------------------------------------------------
--	<> ALL ES EQUIVALENTE A NOT IN
------------------------------------------------------------------------------------------
SELECT ID
FROM _A
WHERE ID <>ALL(SELECT ID FROM _B)


SELECT  [Name],
		[ListPrice]
FROM 
		[Production].[Product]
WHERE 
		[ListPrice] > ANY	(
								SELECT  DISTINCT
										([ListPrice])
								FROM 
										[Production].[Product]
							) 
ORDER BY [ListPrice] 

------------------------------------------------------------------------------------------
--	INSERT INTO
------------------------------------------------------------------------------------------
SELECT 
		* 
INTO
		#Clientes
FROM 
		[Person].[Address]
WHERE 
		[AddressLine2] IS NOT NULL


SELECT 
		* 
FROM
		#Clientes
 



 IF OBJECT_ID (N'tempdb..#Clientes', N'U') IS NOT NULL
		DROP TABLE #Clientes;

CREATE TABLE #Clientes
(
		ID  INT,
		PRIMARY KEY(ID)
)

SELECT * FROM #Clientes

IF OBJECT_ID (N'tempdb..#Clientes', N'U') IS NOT NULL
		DROP TABLE #Clientes;


SELECT ID,
		CASE WHEN ID BETWEEN 1 AND 3 THEN 'VUELVA EN MARZO'
			 WHEN ID BETWEEN 4 AND 6 THEN 'APROBO RASPANDO' 
			 WHEN ID BETWEEN 7 AND 8 THEN 'ALGO SABE' 
			 WHEN ID =9  THEN 'SABE MUCHO'
			 ELSE 
					'PARE DE ESTUDIAR TANTO'
		END 'ACCION'
FROM _A

IF OBJECT_ID (N'_A', N'U') IS NOT NULL
		DROP TABLE _A;
IF OBJECT_ID (N'_B', N'U') IS NOT NULL
		DROP TABLE _B;