USE [AdventureWorks2012]
go


IF OBJECT_ID (N'dbo.cliente_sectores', N'U') IS NOT NULL  
	DROP TABLE dbo.cliente_sectores;
 
CREATE TABLE dbo.cliente_sectores
(
  id_cliente_sector		TINYINT 	NOT NULL	IDENTITY(1,1),
  sector	 			VARCHAR(50)				DEFAULT 'sin sector',
  subgerencia 			VARCHAR(50)				DEFAULT 'sin subgerencia',
  gerencia				VARCHAR(50)				DEFAULT 'sin sector'+'/'+'sin subgerencia',
  region				VARCHAR(50)				DEFAULT  NULL
  CONSTRAINT	PK_id_cliente_sector 
				PRIMARY KEY  (id_cliente_sector)
);

IF OBJECT_ID (N'dbo.sectores', N'U') IS NOT NULL  
	DROP TABLE dbo.sectores;

CREATE TABLE dbo.sectores
(
  id_sector				TINYINT 	NOT NULL	IDENTITY(1,1),
  sector	 			VARCHAR(50),			
  sectornuevo 			VARCHAR(50),				
  CONSTRAINT	PK_id_sector
				PRIMARY KEY  (id_sector)
);

/************************************************************************************
*																					*
*							INSERTAR REGISTROS	BULK_COPY							*
*																					*
************************************************************************************/

IF OBJECT_ID (N'dbo.domicilio', N'U') IS NOT NULL  
	DROP TABLE dbo.domicilio;

SELECT						-- CAMPOS QUE TENDRAN
		[AddressID],
		[AddressLine1],
		[PostalCode]
INTO
		dbo.domicilio  -- NOMBRE QUE LLEVARA LOS DATOS 
FROM 
		[Person].[Address];		-- DE DONDE PROVEIENEN LOS CAMPOS

SELECT * FROM dbo.domicilio;			-- HACEMOS UN CREATE DE LA TABLA APARTIR DE UN SELECT.

IF OBJECT_ID (N'dbo.domicilio', N'U') IS NOT NULL  
	DROP TABLE dbo.domicilio;


---------------------------------------------------------------------------------------
--							INSERT INTO [DEFAULT VALUES]
-- Tiene una propiedad IDENTITY. Se usa el valor de identidad incremental siguiente.
-- Tiene un valor predeterminado. Se usa el valor predeterminado de la columna.
-- Tiene un tipo de datos timestamp. Se utiliza el valor actual de marca de hora.
-- Acepta valores NULL. Se usa un valor NULL.
-- Es una columna calculada. Se utiliza el valor calculado.
----------------------------------------------------------------------------------------
INSERT INTO dbo.cliente_sectores DEFAULT VALUES;
---------------------------------------------------------------------------------------
--						INSERT INTO CON DEFINICION DE CAMPOS
-- No se debe especificar el campo que posea la propiedad IDENTITY.
----------------------------------------------------------------------------------------
INSERT INTO dbo.cliente_sectores (sector, subgerencia, gerencia, region)
		VALUES ('cuentas', 'cobranzas', 'finanzas', 'latam');
INSERT INTO dbo.cliente_sectores (sector, subgerencia, gerencia)
		VALUES ('cuentas', 'cobranzas', 'finanzas');

---------------------------------------------------------------------------------------
--						INSERT INTO SIN DEFINICION DE CAMPOS
-- No se debe especificar el campo que posea la propiedad IDENTITY.
----------------------------------------------------------------------------------------
INSERT INTO dbo.cliente_sectores
		VALUES ('cuentas', 'cobranzas', 'finanzas', 'latam')
INSERT INTO dbo.cliente_sectores
		VALUES	('pagos',  'cobranzas', 'finanzas', 'latam'),
				('cobros', 'cobranzas', 'finanzas', 'local'),
				('deudas', 'cobranzas', 'finanzas',  DEFAULT);

---------------------------------------------------------------------------------------
--						INSERT INTO CON UN SELECT
-- No se debe especificar el campo que posea la propiedad IDENTITY.
-- No se puede especificar la constante DEFAULT.
----------------------------------------------------------------------------------------
INSERT INTO dbo.cliente_sectores (sector, subgerencia, gerencia, region)
SELECT 'cajas', 'cobranzas', 'finanzas',  NULL;

---------------------------------------------------------------------------------------
--				INSERT INTO CON UN PROCEDIMIENTO ALMACENADO
-- No se debe especificar el campo que posea la propiedad IDENTITY.
-- No se puede especificar la constante DEFAULT.
----------------------------------------------------------------------------------------
-- Creacion del procedimeiento
IF OBJECT_ID (N'dbo_altafinanzas', N'P') IS NOT NULL
		DROP PROCEDURE dbo.dbo_altafinanzas;
go		  
CREATE PROCEDURE dbo_altafinanzas
AS BEGIN 
		SELECT 'cajas', 'cobranzas', 'finanzas', 'interno';
END
go

-- Ejecucion del procedimeiento
EXEC dbo.dbo_altafinanzas;

-- Insercion desde el resultado de la ejecucion del prodedimiento
INSERT	INTO dbo.cliente_sectores 
		EXEC dbo.dbo_altafinanzas;


SELECT 
		id_cliente_sector,
		sector,
		subgerencia,
		gerencia,
		region
FROM 
		dbo.cliente_sectores;

/************************************************************************************
*																					*
*								MODIFICAR REGISTROS									*
*																					*
************************************************************************************/
UPDATE	dbo.cliente_sectores
		SET region=ISNULL(region,'desconocido')
WHERE region IS NULL;


INSERT INTO dbo.sectores (sector, sectornuevo)
	VALUES ('cajas', 'tesoreria')


UPDATE  dbo.cliente_sectores
		SET sector=sectornuevo
FROM	
		dbo.cliente_sectores c

		INNER JOIN dbo.sectores s
		ON c.sector=s.sector;

SELECT 
		id_cliente_sector,
		sector,
		subgerencia,
		gerencia,
		region
FROM 
		dbo.cliente_sectores;

/***************************************************************************************************************************************************************
																																											
															ELIMINAR REGISTROS	[DELETE-TRUNCATE]																																																										

							TRUNCATE TABLE																	DELETE FROM

Es una operaci�n DDL.																Es una operaci�n DML.
TRUNCATE TABLE elimina todo el contenido de la tabla.								DELETE permite el borrado selectivo, mediante la clausula WHERE.
No se puede ejecutar, si la tabla tiene asociadas FK.								Se puede ejecutar, si la tabla tiene asociadas FK.
Es la forma m�s r�pida de eliminar el contenido de una tabla.						Es la forma m�s lenta de eliminar el contenido de una tabla.
No es posible tener acceso a los valores que fueron eliminados(DDL trigger). 		Puede activarse el trigger de ON DELETE y determinar registros afectados.
Reseteo de campo Identity al valor base determinado en el campo.					No resetea el valor del campo Identity.
TRUNCATE TABLE desasocia (deallocate) las p�ginas de datos de la tabla.				DELETE FROM marca cada registro afectado, como eliminado.
Solo registra el dealloc de las p�ginas de datos.									Loguea cada operaci�n sobre los registros afectados.
No puede ser ejecutado si la tabla tiene asociadas vistas indexadas.				Se puede ejecutar si la tabla tiene vistas indexadas.

****************************************************************************************************************************************************************/

DELETE FROM	
		dbo.cliente_sectores	
WHERE 
		region='desconocido'

DELETE  dbo.cliente_sectores
FROM	
		dbo.cliente_sectores c

		INNER JOIN dbo.sectores s
		ON c.sector=s.sectornuevo;

SELECT 
		id_cliente_sector,
		sector,
		subgerencia,
		gerencia,
		region
FROM 
		dbo.cliente_sectores;

--TRUNCATE TABLE dbo.cliente_sectores;

/************************************************************************************
*																					*
*					INSERTAR MODIFICAR ELIMINAR REGISTROS CON MERGE					*
*																					*
************************************************************************************/

MERGE  
		dbo.cliente_sectores AS TARGET  --TABLA OBJETIVO
USING	(SELECT 7 as id, 'deposito' as sector, null as subgerencia, 'logistica' as gerencia, 'latam' as region) AS Source -- ORIGEN DE DATOS
ON		(TARGET.sector = Source.sector)

WHEN MATCHED THEN UPDATE 
		SET TARGET.sector = Source.sector,  TARGET.region = Source.region
WHEN NOT MATCHED BY TARGET THEN
		INSERT (sector, subgerencia, gerencia, region)
				VALUES (Source.sector,Source.subgerencia, Source.gerencia, Source.region)
WHEN NOT MATCHED BY SOURCE THEN
		DELETE;


SELECT 
		id_cliente_sector,
		sector,
		subgerencia,
		gerencia,
		region
FROM 
		dbo.cliente_sectores;
